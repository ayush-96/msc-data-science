package bigdata.objects;

import bigdata.technicalindicators.Volitility;
import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.expressions.Window;
import org.apache.spark.sql.expressions.WindowSpec;
import org.apache.spark.sql.functions;

import java.util.List;

import bigdata.technicalindicators.Volitility;
import static org.apache.spark.sql.functions.*;

public class AssetVolatility {
    private String symbol;
    private double volatility;

    // Constructors, getters, setters

    public AssetVolatility() {}

    public AssetVolatility(String symbol, double volatility) {
        this.symbol = symbol;
        this.volatility = volatility;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public double getVolatility() {
        return volatility;
    }

    public void setVolatility(double volatility) {
        this.volatility = volatility;
    }

    public static Dataset<AssetVolatility> calculateVolatility(Dataset<Row> assets, Double volatilityCeiling){
        WindowSpec windowSpec = Window.partitionBy("symbol").orderBy(functions.col("trading_date").desc());

        Dataset<Row> volatilityDS = assets.withColumn("vrank", functions.dense_rank().over(windowSpec));
        volatilityDS = volatilityDS.filter(col("vrank").leq(251));

        Dataset<Row> groupedVolatilityDS = volatilityDS
                .withColumn("orderedPrices", functions.collect_list(col("closePrice"))
                        .over(Window.partitionBy("symbol").orderBy(col("trading_date").desc())))
                .groupBy("symbol")
                .agg(functions.max(col("orderedPrices")).as("closePrices"));

        Dataset<AssetVolatility> calculatedVolatilityDS = groupedVolatilityDS.map(
                (MapFunction<Row, AssetVolatility>) row -> {
                    String symbol = row.getString(0);  // getting the symbol for the stock
                    List<Double> closePrices = row.getList(1);  // getting the closed price list
                    double calculatedVolatility = Volitility.calculate(closePrices);  // Volatility calculate function
                    return new AssetVolatility(symbol, calculatedVolatility);
                },
                Encoders.bean(AssetVolatility.class)
        );

        // filtering as per volatility ceiling
        calculatedVolatilityDS = calculatedVolatilityDS.filter(col("volatility").lt(volatilityCeiling));

        return calculatedVolatilityDS;
    }
}
