package bigdata.objects;

import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.expressions.Window;
import org.apache.spark.sql.expressions.WindowSpec;
import org.apache.spark.sql.functions;

import java.util.List;

import static bigdata.technicalindicators.Returns.calculate;
import static org.apache.spark.sql.functions.*;

public class AssetReturn {
    private String symbol;
    private double returns;

    // Constructors, getters, setters

    public AssetReturn() {}

    public AssetReturn(String symbol, double returns) {
        this.symbol = symbol;
        this.returns = returns;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public double getReturns() {
        return returns;
    }

    public void setReturns(double returns) {
        this.returns = returns;
    }

    public static Dataset<AssetReturn> calculateReturns(Dataset<Row> assets) {
        WindowSpec windowSpec = Window.partitionBy("symbol").orderBy(functions.col("trading_date").desc());

        Dataset<Row> returnsDS = assets.withColumn("rrank", functions.rank().over(windowSpec));
        returnsDS = returnsDS.filter("rrank <= 6");

        // Collecting close prices into a dataset for each symbol -> String symbol, List<double> close prices
        Dataset<Row> groupedReturnsDS = returnsDS.groupBy("symbol")
                .agg(sort_array(collect_list(col("closePrice")), true));

        // Calculating returns
        return groupedReturnsDS.map((MapFunction<Row, AssetReturn>) row ->
                        new AssetReturn(row.getString(0), calculate(5, row.getList(1))),
                Encoders.bean(AssetReturn.class)
        );
    }

    public static Asset[] getTopAssets(Dataset<Row> assets) {

        // Collecting the rows from finalDS
        List<Row> assetRows = assets.collectAsList();

        Asset[] topAssets = new Asset[5];

        for (int i = 0; i < assetRows.size(); i++) {
            Row row = assetRows.get(i);

            // Creating AssetFeatures object
            AssetFeatures features = new AssetFeatures();
            features.setAssetReturn(row.getDouble(5));
            features.setAssetVolitility(row.getDouble(6));
            features.setPeRatio(row.getDouble(4));

            // Creating Asset object
            Asset asset = new Asset(row.getString(0),
                    features,
                    row.getString(1),
                    row.getString(2),
                    row.getString(3));

            topAssets[i] = asset;
        }
        return topAssets;
    }
}

